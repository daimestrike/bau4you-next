# Supabase Proxy для VPS

## Установка на VPS

1. Загрузите все файлы в `/var/www/supabase-proxy/`
2. Выполните: `npm install`
3. Выполните: `npm run build`
4. Запустите: `pm2 start npm --name "supabase-proxy" -- start`

## Тестирование

```bash
curl "https://api.bau4you.co/api/sb/rest/v1/commercial_proposals?limit=1" \
  -H "Content-Type: application/json"
```

Должен вернуть JSON ответ от Supabase.
